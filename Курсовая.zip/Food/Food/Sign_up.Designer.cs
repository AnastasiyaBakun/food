﻿namespace Food
{
    partial class Sign_up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sign_up));
            this.label1 = new System.Windows.Forms.Label();
            this.button_create = new System.Windows.Forms.Button();
            this.textBox_password2 = new System.Windows.Forms.TextBox();
            this.textBox_login2 = new System.Windows.Forms.TextBox();
            this.label_password2 = new System.Windows.Forms.Label();
            this.label_login2 = new System.Windows.Forms.Label();
            this.pictureBox_show2 = new System.Windows.Forms.PictureBox();
            this.pictureBox_hide2 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_show2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_hide2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkViolet;
            this.label1.Location = new System.Drawing.Point(247, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Регистрация";
            // 
            // button_create
            // 
            this.button_create.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_create.AutoSize = true;
            this.button_create.BackColor = System.Drawing.Color.Plum;
            this.button_create.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_create.Font = new System.Drawing.Font("Microsoft Tai Le", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_create.Location = new System.Drawing.Point(252, 337);
            this.button_create.Name = "button_create";
            this.button_create.Size = new System.Drawing.Size(211, 54);
            this.button_create.TabIndex = 10;
            this.button_create.Text = "Создать аккаунт";
            this.button_create.UseVisualStyleBackColor = false;
            this.button_create.Click += new System.EventHandler(this.button_create_Click);
            // 
            // textBox_password2
            // 
            this.textBox_password2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_password2.ForeColor = System.Drawing.Color.DarkViolet;
            this.textBox_password2.Location = new System.Drawing.Point(235, 239);
            this.textBox_password2.MaxLength = 50;
            this.textBox_password2.Multiline = true;
            this.textBox_password2.Name = "textBox_password2";
            this.textBox_password2.Size = new System.Drawing.Size(259, 35);
            this.textBox_password2.TabIndex = 9;
            // 
            // textBox_login2
            // 
            this.textBox_login2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_login2.ForeColor = System.Drawing.Color.DarkViolet;
            this.textBox_login2.Location = new System.Drawing.Point(235, 174);
            this.textBox_login2.MaxLength = 50;
            this.textBox_login2.Multiline = true;
            this.textBox_login2.Name = "textBox_login2";
            this.textBox_login2.Size = new System.Drawing.Size(259, 35);
            this.textBox_login2.TabIndex = 8;
            // 
            // label_password2
            // 
            this.label_password2.AutoSize = true;
            this.label_password2.BackColor = System.Drawing.Color.Transparent;
            this.label_password2.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_password2.ForeColor = System.Drawing.Color.DarkViolet;
            this.label_password2.Location = new System.Drawing.Point(81, 239);
            this.label_password2.Name = "label_password2";
            this.label_password2.Size = new System.Drawing.Size(130, 35);
            this.label_password2.TabIndex = 7;
            this.label_password2.Text = "Пароль:";
            // 
            // label_login2
            // 
            this.label_login2.AutoSize = true;
            this.label_login2.BackColor = System.Drawing.Color.Transparent;
            this.label_login2.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_login2.ForeColor = System.Drawing.Color.DarkViolet;
            this.label_login2.Location = new System.Drawing.Point(102, 174);
            this.label_login2.Name = "label_login2";
            this.label_login2.Size = new System.Drawing.Size(107, 35);
            this.label_login2.TabIndex = 6;
            this.label_login2.Text = "Логин:";
            // 
            // pictureBox_show2
            // 
            this.pictureBox_show2.BackColor = System.Drawing.Color.White;
            this.pictureBox_show2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_show2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_show2.Image")));
            this.pictureBox_show2.Location = new System.Drawing.Point(515, 239);
            this.pictureBox_show2.Name = "pictureBox_show2";
            this.pictureBox_show2.Size = new System.Drawing.Size(42, 35);
            this.pictureBox_show2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_show2.TabIndex = 12;
            this.pictureBox_show2.TabStop = false;
            this.pictureBox_show2.Click += new System.EventHandler(this.pictureBox_show2_Click);
            // 
            // pictureBox_hide2
            // 
            this.pictureBox_hide2.BackColor = System.Drawing.Color.White;
            this.pictureBox_hide2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_hide2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_hide2.Image")));
            this.pictureBox_hide2.Location = new System.Drawing.Point(515, 239);
            this.pictureBox_hide2.Name = "pictureBox_hide2";
            this.pictureBox_hide2.Size = new System.Drawing.Size(42, 35);
            this.pictureBox_hide2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_hide2.TabIndex = 11;
            this.pictureBox_hide2.TabStop = false;
            this.pictureBox_hide2.Click += new System.EventHandler(this.pictureBox_hide2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = global::Food.Properties.Resources.BackArrow;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(20, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(43, 39);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Sign_up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Food.Properties.Resources.Форма_регистрации;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(715, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox_show2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox_hide2);
            this.Controls.Add(this.button_create);
            this.Controls.Add(this.textBox_password2);
            this.Controls.Add(this.textBox_login2);
            this.Controls.Add(this.label_password2);
            this.Controls.Add(this.label_login2);
            this.MaximumSize = new System.Drawing.Size(733, 497);
            this.MinimumSize = new System.Drawing.Size(733, 497);
            this.Name = "Sign_up";
            this.Text = "Sign up";
            this.Load += new System.EventHandler(this.Sign_up_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_show2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_hide2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_create;
        private System.Windows.Forms.TextBox textBox_password2;
        private System.Windows.Forms.TextBox textBox_login2;
        private System.Windows.Forms.Label label_password2;
        private System.Windows.Forms.Label label_login2;
        private System.Windows.Forms.PictureBox pictureBox_hide2;
        private System.Windows.Forms.PictureBox pictureBox_show2;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}